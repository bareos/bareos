use Socket;
    
    socket(SERVER, PF_UNIX, SOCK_STREAM, 0);
    unlink "sock-file";
    bind(SERVER, sockaddr_un("sock-file"))
        or die "Can't create server: $!";
